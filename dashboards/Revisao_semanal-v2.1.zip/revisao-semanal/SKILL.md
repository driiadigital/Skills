---
name: revisao-semanal
description: Cria o dashboard HTML da revisão semanal das reuniões da Outlier Agency a partir das transcrições do Fireflies, com o layout oficial Work Management (barra lateral com o logótipo da Outlier e oito secções: visão geral, clientes e projetos, plano de ação, prioridades, resumo das reuniões, resultados em destaque, análise semanal e fontes). Usa esta skill sempre que for pedida a revisão semanal das reuniões, o dashboard semanal ou o resumo da semana da Outlier. Não a uses para hotseats da Incubadora, que têm a skill resumo-hotseat. Quando a usares, nunca cries o HTML de raiz nem alteres o template.
---

# Revisão semanal das reuniões da Outlier

O layout está fechado em `assets/template.html`. O teu trabalho é só escrever os dados num JSON. O script `scripts/gerar_dashboard.py` junta os dados ao template e verifica as regras. Não escrevas HTML, não alteres o template e não uses outra forma de gerar a página.

## Passos

1. Período: usa o que a tarefa indicar. Se não indicar, é de segunda-feira da semana em curso até à data de execução.
2. Lista no Fireflies todas as reuniões gravadas no período, seja quem for o organizador. Aplica as exclusões (ver Âmbito).
3. Lê cada transcrição inteira. Tira do Fireflies o id, o título, a data, a hora, a duração e os participantes.
4. Lê `references/exemplo.json` para veres a estrutura, o nível de detalhe e o tom esperados. Os participantes do exemplo estão vazios de propósito; nos dados reais são obrigatórios.
5. Escreve os dados num ficheiro `dados.json` com a estrutura abaixo.
6. Corre: `python3 <pasta da skill>/scripts/gerar_dashboard.py dados.json "revisao-semanal-AAAA-MM-DD.html" --publicar "revisao-semanal-AAAA-MM-DD-publicar.html"`. O segundo ficheiro é a cópia já preparada para publicar como Artifact (sem doctype, html, head, body nem metas). Não a prepares à mão.
7. Se o script devolver ERRO, corrige o JSON e volta a correr. Não contornes a verificação. Se um ponto não tiver solução com os dados disponíveis, corrige-o da forma mais conservadora (por exemplo, retira o item) e explica porquê em RESSALVAS.
8. Entrega o HTML onde a tarefa indicar, com uma mensagem curta: estado geral da semana, os cinco números (reuniões analisadas, decisões tomadas, tarefas em aberto, tarefas vencidas, pontos de atenção) e as três prioridades, uma linha cada. Os números estão na linha "Resumo" que o script imprime; não os contes à mão.

## Âmbito

- Todas as reuniões gravadas no Fireflies no período, seja quem for o organizador.
- Não analisas os hotseats da Incubadora, as gravações que não são reuniões nem as reuniões internas sobre pessoas da equipa. Estas aparecem só em EXCLUIDAS, sempre apenas pela contagem, sem título nem nomes (por exemplo, "2 gravações que não eram reuniões").
- Reunião do período ainda sem transcrição: não a analisas e indicas em RESSALVAS: "[título], [data]: transcrição ainda não disponível, não analisada."
- Se não conseguires ler uma reunião inteira, indicas no campo nota da reunião que partes ficaram por ler.

## Público e tom

- O dashboard é lido por toda a equipa. Português europeu, terceira pessoa, frases curtas e diretas.
- Sem comentários sobre pessoas da equipa, remunerações ou assuntos pessoais.
- Sem travessões (— ou –). Intervalos escrevem-se "20 a 30".
- Datas sempre escritas (27/09), nunca "hoje", "amanhã" ou "ontem".

## Nomes

- Equipa Outlier: Daniel Godinho, Maria João, Guilherme, Suzyany ("Suzy" é a Suzyany), Adriele. Qualquer outra pessoa é cliente, contacto ou parceiro.
- Clientes e contactos vêm do título da reunião e da lista de participantes. Um nome que só aparece na transcrição de voz leva "(nome a confirmar)" e entra em NOMES.
- Uma tarefa só tem responsável (q) quando isso é dito explicitamente ou quando havia uma única pessoa da Outlier na chamada. Nos outros casos, q é null.

## Critérios

- Usas apenas o que está nas transcrições. Não inventas responsáveis, prazos, números, minutos nem participantes.
- Cada item liga à reunião de onde vem. Decisões, números e tarefas concluídas levam também o minuto.
- Decisões: só o que ficou fechado de forma explícita.
- Tarefas: pedidos com um resultado concreto, surgidos nas reuniões do período. Só são concluídas (feita) com confirmação numa reunião do período, com reunião e minuto.
- Valores em euros. Se a transcrição mostrar R$ ou nenhuma unidade, acrescentas "(unidade a confirmar)".
- Marcas: sem marca, foi dito; "[inferência]" é uma leitura tua; "a confirmar" é um nome, responsável ou minuto que não consegues confirmar.
- Cada facto aparece num só sítio. Os números de um cliente ficam no cartão. Prioridades e análise nomeiam o cliente sem repetir os números. O detalhe de um cartão não repete a frase principal nem as decisões.
- Se houver contradições entre cartões, tarefas e decisões, mostras as duas versões com "a confirmar" e explicas em RESSALVAS.

## Estrutura do JSON

Todas as chaves são obrigatórias. Referências são sempre `[chave da reunião, "MM:SS" ou "H:MM:SS" ou null]`. Datas em AAAA-MM-DD.

- `SEMANA`: `{inicio, fim, gerado}`. gerado é a data de execução.
- `M`: reuniões analisadas, por chave curta (2 a 3 letras). Cada uma: `id` (id do Fireflies), `nome` (título), `curto` (nome curto para os links), `data`, `hora` (HH:MM, Lisboa), `dur` (minutos, número), `part` (lista de participantes), `nota` (opcional, por exemplo partes por ler).
- `PRIOS`: exatamente 3, são inferência. `{h, passo, q, p, k, r}`: título curto, primeiro passo numa frase, responsável e prazo só se ditos (senão null), id do cartão ligado (ou null), referências. `{SEMRESP}` no título é substituído pelo número de tarefas sem responsável.
- `PERGUNTA`: `{q, porque, r}`. Uma pergunta para a reunião de equipa e o porquê numa frase.
- `CARDS`: um por cliente ou tema interno. `{id, h, e, o, d, r}`. e é `avanca` (A avançar), `atencao` (Precisa de atenção), `bloq` (Bloqueado) ou `semacao` (Sem ação da Outlier). o é o assunto principal numa frase; d é o contexto em até três frases, sem repetir o.
- `TASKS`: `{q, o, k, p, s, r, feita}`. o começa por um verbo no infinitivo. k é o id do cartão (null se for interno sem cartão). s é opcional e só entra quando acrescenta algo. feita só com confirmação. A próxima ação de cada cartão é calculada pelo template a partir daqui.
- `DECS`: `{x, m, t, c}`. t (minuto) é obrigatório. c é o id do cartão (ou null).
- `BEM` e `PADROES`: até 3 cada. `BEM`: `{t, r}`. `PADROES`: `{h, p, r}`. Só o que atravessa vários clientes ou acrescenta algo que não está nos cartões, prioridades nem tarefas. Se não houver nada, lista vazia.
- `EXCLUIDAS`, `NOMES`, `RESSALVAS`: listas de frases.
- `DESTAQUES`: 0 a 4 resultados com número, ditos numa reunião. `{v, l, n, k, r}`: valor curto ("58", "3,65€"), o que mede, contexto numa frase (opcional), id do cartão (ou null) e referências com minuto (obrigatório). É a única exceção à regra de cada facto num só sítio: repete um número do cartão com a fonte. Se não houver números relevantes, lista vazia e a secção não aparece. Exemplo: `{"v": "58", "l": "vendas do ebook do Simão", "n": "Só uma compra adicional.", "k": "si", "r": [["SI", "15:22"]]}`.

O template calcula sozinho o período, a data de geração, o estado geral da semana, os cinco números, os gráficos da visão geral, o resumo por reunião, a carga por pessoa, a próxima ação de cada cartão, os grupos de tarefas, os filtros, a pesquisa e os contadores da barra lateral. Não os escrevas.

O script recusa gerar o ficheiro se o template tiver sido alterado fora do bloco de dados ou se faltar alguma das oito secções. Se isso acontecer, não tentes corrigir o template: reporta o erro.
