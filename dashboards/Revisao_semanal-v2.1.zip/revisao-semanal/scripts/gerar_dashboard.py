#!/usr/bin/env python3
"""Gera o dashboard da revisão semanal a partir de um JSON de dados,
usando o template oficial (assets/template.html) como base.

Uso: python3 gerar_dashboard.py dados.json "saida.html" [--publicar "saida-publicar.html"]

O script só substitui o conteúdo do bloco <script id="dados-semana"> do template.
Antes de gerar, verifica as regras. Se encontrar problemas, termina com ERRO e não cria o ficheiro.
Com --publicar, cria também a cópia para publicar como Artifact (sem doctype, html, head,
body nem metas: fica o conteúdo do head, seguido do conteúdo do body).
"""
import datetime, json, os, re, sys

AQUI = os.path.dirname(os.path.abspath(__file__))
TEMPLATE = os.path.join(AQUI, '..', 'assets', 'template.html')
ABRE = '<script id="dados-semana">'
INI = '/* ===================== DADOS DA SEMANA ===================== */'
CHAVES = ['SEMANA', 'M', 'PRIOS', 'PERGUNTA', 'CARDS', 'TASKS', 'DECS',
          'BEM', 'PADROES', 'EXCLUIDAS', 'NOMES', 'RESSALVAS', 'DESTAQUES']
OPCIONAIS = {'DESTAQUES': []}
ESTADOS = {'avanca', 'atencao', 'bloq', 'semacao'}
SECCOES = ['visao', 'clientes', 'plano', 'prioridades', 'reunioes', 'resultados', 'analise', 'fontes']
LETRA = r'[^\W\d_]'


def sec(t):
    p = [int(x) for x in t.split(':')]
    return p[0] * 3600 + p[1] * 60 + p[2] if len(p) == 3 else p[0] * 60 + p[1]


def curto(s):
    s = (s or '').replace('[inferência]', '').strip()
    return s if len(s) <= 70 else s[:67] + '...'


def textos(x, fora=()):
    """Todas as strings do JSON, exceto as chaves de topo em fora."""
    if isinstance(x, dict):
        for k, v in x.items():
            if k in fora:
                continue
            yield from textos(v)
    elif isinstance(x, list):
        for v in x:
            yield from textos(v)
    elif isinstance(x, str):
        yield x


def verificar(d):
    for k, v in OPCIONAIS.items():
        d.setdefault(k, v)
    falta = [k for k in CHAVES if k not in d]
    if falta:
        sys.exit('ERRO, corrige o JSON e volta a correr:\nFaltam as chaves: ' + ', '.join(falta))
    e = []
    M = d['M']

    def data(s, onde):
        if s is None:
            return
        if not isinstance(s, str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}', s):
            e.append(f'{onde}: data "{s}" não está em AAAA-MM-DD.')
            return
        try:
            datetime.date.fromisoformat(s)
        except ValueError:
            e.append(f'{onde}: data "{s}" não existe.')

    def ref(r, onde, obrig=False):
        if not r or not r[0]:
            e.append(f'{onde}: reunião por identificar.')
            return
        if r[0] not in M:
            e.append(f'{onde}: a reunião "{r[0]}" não está em M.')
            return
        t = r[1] if len(r) > 1 else None
        if not t:
            if obrig:
                e.append(f'{onde}: falta o minuto.')
            return
        if not re.fullmatch(r'\d{1,2}:\d{2}(:\d{2})?', t):
            e.append(f'{onde}: minuto "{t}" em formato inválido.')
            return
        if sec(t) > M[r[0]]['dur'] * 60:
            e.append(f'{onde}: o minuto {t} passa a duração da reunião ({M[r[0]]["dur"]} min).')

    S = d['SEMANA']
    for k in ('inicio', 'fim', 'gerado'):
        if k not in S:
            e.append(f'SEMANA: falta "{k}".')
        data(S.get(k), f'SEMANA.{k}')

    if not M:
        e.append('M está vazio: sem reuniões analisadas não há dashboard.')
    for k, m in M.items():
        for c in ('id', 'nome', 'curto', 'data', 'hora', 'dur'):
            if c not in m:
                e.append(f'Reunião {k}: falta "{c}".')
        data(m.get('data'), f'Reunião {k}')
        if not m.get('part'):
            e.append(f'Reunião {m.get("curto", k)}: participantes por preencher.')

    ids = set()
    for c in d['CARDS']:
        if c.get('id') in ids:
            e.append(f'Cartão "{c.get("h")}": id repetido.')
        ids.add(c.get('id'))
        if c.get('e') not in ESTADOS:
            e.append(f'Cartão "{c.get("h")}": estado "{c.get("e")}" desconhecido.')
        if not c.get('r'):
            e.append(f'Cartão "{c.get("h")}": sem fonte.')
        for r in c.get('r') or []:
            ref(r, f'Cartão "{c.get("h")}"')

    if len(d['PRIOS']) != 3:
        e.append(f'Há {len(d["PRIOS"])} prioridades; devem ser 3.')
    for p in d['PRIOS']:
        o = f'Prioridade "{curto(p.get("h"))}"'
        if p.get('k') and p['k'] not in ids:
            e.append(f'{o}: o cartão "{p["k"]}" não existe.')
        data(p.get('p'), o)
        for r in p.get('r') or []:
            ref(r, o)

    for c in ('q', 'porque'):
        if not d['PERGUNTA'].get(c):
            e.append(f'Pergunta: falta "{c}".')
    for r in d['PERGUNTA'].get('r') or []:
        ref(r, 'Pergunta')

    for t in d['TASKS']:
        o = f'Tarefa "{curto(t.get("o"))}"'
        ref(t.get('r'), o)
        data(t.get('p'), o)
        data(t.get('desde'), o)
        if t.get('k') and t['k'] not in ids:
            e.append(f'{o}: o cartão "{t["k"]}" não existe.')
        if t.get('feita'):
            ref(t['feita'], o + ' (confirmação)', obrig=True)

    for x in d['DECS']:
        o = f'Decisão "{curto(x.get("x"))}"'
        ref([x.get('m'), x.get('t')], o, obrig=True)
        if x.get('c') and x['c'] not in ids:
            e.append(f'{o}: o cartão "{x["c"]}" não existe.')

    if len(d['BEM']) > 3:
        e.append(f'"Correu bem" tem {len(d["BEM"])} pontos; o máximo é 3.')
    if len(d['PADROES']) > 3:
        e.append(f'"Padrões" tem {len(d["PADROES"])} pontos; o máximo é 3.')
    for b in d['BEM']:
        if not b.get('r'):
            e.append(f'Correu bem "{curto(b.get("t"))}": sem fonte.')
        for r in b.get('r') or []:
            ref(r, f'Correu bem "{curto(b.get("t"))}"')
    for p in d['PADROES']:
        if not p.get('r'):
            e.append(f'Padrão "{p.get("h")}": sem fonte.')
        for r in p.get('r') or []:
            ref(r, f'Padrão "{p.get("h")}"')

    if len(d['DESTAQUES']) > 4:
        e.append(f'"Resultados em destaque" tem {len(d["DESTAQUES"])} pontos; o máximo é 4.')
    for x in d['DESTAQUES']:
        o = f'Destaque "{curto(str(x.get("v", "")) + " " + str(x.get("l", "")))}"'
        if not x.get('v') or not x.get('l'):
            e.append(f'{o}: falta o valor (v) ou a descrição (l).')
        if x.get('k') and x['k'] not in ids:
            e.append(f'{o}: o cartão "{x["k"]}" não existe.')
        if not x.get('r'):
            e.append(f'{o}: sem fonte.')
        for r in x.get('r') or []:
            ref(r, o, obrig=True)

    todos = ' '.join(textos(d))
    if re.search('[–—]', todos):
        e.append('Há travessões no texto.')
    corpo = ' '.join(textos(d, fora=('RESSALVAS', 'EXCLUIDAS')))
    rel = re.findall(rf'(?<!{LETRA})(hoje|amanhã|ontem)(?!{LETRA})', corpo, re.I)
    if rel:
        e.append(f'Datas relativas no texto ({", ".join(sorted(set(x.lower() for x in rel)))}): escrever a data.')
    if 'R$' in corpo:
        e.append('Há valores em R$: marcar "(unidade a confirmar)".')
    mil = re.findall(rf'\d[\d.,]*\s*mil(?!{LETRA})(?!\s*€)(?!\s*\(unidade a confirmar\))', corpo, re.I)
    if mil:
        e.append(f'Valores sem unidade: {", ".join(mil)}.')

    if e:
        sys.exit('ERRO, corrige o JSON e volta a correr:\n' + '\n'.join(f'- {x}' for x in e))


def bloco_dados(s):
    """Posições do conteúdo do <script id="dados-semana"> (sem as tags)."""
    m = re.search(r'^' + re.escape(ABRE), s, re.M)  # a etiqueta real, no início da linha (não a do comentário)
    if not m:
        sys.exit('ERRO no template: não encontro <script id="dados-semana">. O template foi alterado.')
    a = m.end()
    b = s.find('</script>', a)
    if b < 0 or INI not in s[a:b]:
        sys.exit('ERRO no template: o bloco de dados está incompleto. O template foi alterado.')
    return a, b


def para_publicar(html):
    """Cópia para o Artifact: conteúdo do head (sem metas) seguido do conteúdo do body."""
    head = re.search(r'<head[^>]*>(.*?)</head>', html, re.S | re.I).group(1)
    body = re.search(r'<body[^>]*>(.*)</body>', html, re.S | re.I).group(1)
    head = re.sub(r'\s*<meta\b[^>]*>', '', head, flags=re.I)
    return head.strip() + '\n' + body.strip() + '\n'


def gerar(d, saida, publicar=None):
    verificar(d)
    s = open(TEMPLATE, encoding='utf8').read()
    a, b = bloco_dados(s)
    linhas = [f'const {k}={json.dumps(d[k], ensure_ascii=False)};' for k in CHAVES]
    bloco = '\n' + INI + '\n' + '\n'.join(linhas).replace('</', '<\\/') + '\n\n'
    html = s[:a] + bloco + s[b:]
    # integridade: fora do bloco de dados, o ficheiro tem de ser igual ao template
    a2, b2 = bloco_dados(html)
    if html[:a2] + html[b2:] != s[:a] + s[b:]:
        sys.exit('ERRO: o ficheiro gerado difere do template fora do bloco de dados.')
    falta = [x for x in SECCOES if f'href="#{x}"' not in html or f'id="{x}"' not in html]
    if falta:
        sys.exit('ERRO no template: faltam secções na barra lateral: ' + ', '.join(falta))
    with open(saida, 'w', encoding='utf8') as f:
        f.write(html)
    print(f'OK: {saida}')
    if publicar:
        with open(publicar, 'w', encoding='utf8') as f:
            f.write(para_publicar(html))
        print(f'OK (cópia para publicar): {publicar}')
    n = lambda k: len(d[k])
    abertas = [t for t in d['TASKS'] if not t.get('feita')]
    print(f'Resumo: {n("M")} reuniões, {n("DECS")} decisões, {len(abertas)} tarefas em aberto, '
          f'{sum(1 for t in abertas if not t.get("q"))} sem responsável, '
          f'{sum(1 for t in abertas if t.get("p") and t["p"] < d["SEMANA"]["gerado"])} vencidas, '
          f'{sum(1 for c in d["CARDS"] if c["e"] in ("bloq", "atencao"))} pontos de atenção.')


if __name__ == '__main__':
    args = sys.argv[1:]
    pub = None
    if '--publicar' in args:
        i = args.index('--publicar')
        if i + 1 >= len(args):
            sys.exit('Uso: python3 gerar_dashboard.py dados.json "saida.html" [--publicar "saida-publicar.html"]')
        pub = args[i + 1]
        del args[i:i + 2]
    if len(args) != 2:
        sys.exit('Uso: python3 gerar_dashboard.py dados.json "saida.html" [--publicar "saida-publicar.html"]')
    with open(args[0], encoding='utf8') as f:
        gerar(json.load(f), args[1], pub)
